package dataconnect;
import java.sql.*;
import javax.swing.*;
public class Database {
	
private Connection con;
private Statement st;
private ResultSet rs;

public Database()
{  try{
	  
	 Class.forName("com.mysql.jdbc.Driver") ;
	 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mobilebill?user=root&password=csikc");
 
   }catch(Exception e)
   { JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
   }
}

public void openStatement()
{ try{
	st=con.createStatement();	
 }catch(Exception e)
 { JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
 }
}

public ResultSet getData(String str)
{  try{
	 rs=st.executeQuery(str);
   }catch(Exception e)
   { JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
   }
  return(rs);
}

public int insertUpdataDelete(String s)
{  int i=0;
	 try{
		i=st.executeUpdate(s);
	   }catch(Exception e)
	   { JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
	   }
	return(i);
}

public void closeConnection()
{ try{
	con.close();
  }catch(Exception e)
  { JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
  }
}

public void closeStatemnet()
{ try{
	 st.close();
     }catch(Exception e)
     { JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
      }

}

public void closeResultset()
{try{
	  rs.close();
  }catch(Exception e)
   { JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
   }
}

}