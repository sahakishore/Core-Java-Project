package project;
import dataconnect.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.sql.*;

import java.awt.event.ActionListener;

public class Login extends JFrame {
    private static final long serialVersionUID = 1L;
    private JButton buser,badmin;
    public JTextField tid;
    private JLabel l1,l2,l3;
    private JPasswordField tpass;
    ArrayList<Student> userlist;
    Database db;
    ResultSet rs1;
   //int flag=0;
       
      
   
    public Login(String title)
    { db=new Database();
    // String l8=new String("Admin");
    	//String l9="Admin";
    Container c1=getContentPane();
    c1.setLayout(new GridLayout(17,5));
    buser=new JButton("USER");
    badmin=new JButton("ADMIN");
    
    
        Font f1=new Font("comic sans ms", Font.BOLD,14);
		l2=new JLabel(" User ID :");
		l2.setFont(f1);
		l2.setForeground(Color.RED);
                
        l3=new JLabel(" Enter Password");
		l3.setFont(f1);
		l3.setForeground(Color.RED);
    
        Font f=new Font("Copperplate Gothic Bold", Font.BOLD,14);
		l1=new JLabel("MOBILE BILL GENERATION APPLICATION",SwingConstants.CENTER);
		l1.setFont(f);
		l1.setForeground(Color.RED);
                
         tid=new JTextField(20);
        tpass=new JPasswordField(20);
 
        c1.add(l1);

	    c1.add(l2);
	    c1.add(tid);
	    
	    c1.add(l3);
	    c1.add(tpass);
	    String k=tid.getText().trim();
	    String l=tpass.getText().trim();
   //String s=tid.getText().trim();
    
	    c1.add(new JLabel(""));
	    c1.add(badmin);
	    c1.add(new JLabel(""));
	    c1.add(buser);
   // String l9=new String("Admin");
   // String l8=new String("Admin");
  
    badmin.addActionListener((e) ->{valid();});
    

	 buser.addActionListener((e) ->{validuser();});
    
        
     /* if(k.equals("Admin") && l.equals("Admin"))
      {
        	
        	
            //setVisible(true);
            //badmin.addActionListener((e) ->{new StudentRegistration(title);});
            	
      }
      else
      {
        		
       		JOptionPane.showMessageDialog(this,"INVALID USER ID OR PASSWORD");
        		
      }
        	
        
        
       /* else
        {
        	//JOptionPane.showMessageDialog(this,"INVALID USER ID OR PASSWORD");
        }*/
      /*  if(flag==1)
        {
        	 badmin.addActionListener((e) ->{new StudentRegistration(title);});
        }
        else*/
        	//JOptionPane.showMessageDialog(this,"INVALID USER ID OR PASSWORD");
        
        setSize(500,500);
		setLocation(100,100);
                
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
                
    }     
    
    
    
    
    void valid()
    {

    	String k=tid.getText().trim();
	    String l=tpass.getText().trim();
	  
	    try{
	    if(badmin.getText().equals("ADMIN"))
	    { db.openStatement();
	    rs1=db.getData("select * from login where userid='"+k+"' and Password='"+l+"'");
	    if(rs1.next())
	    {
	        rs1.close();
	        db.closeResultset();
	        this.setVisible(false);
	        JOptionPane.showMessageDialog(this,"Login Success") ;
	        new StudentRegistration("Home page");
	       

	    }
	   else
	      {
	        		
	       		JOptionPane.showMessageDialog(this,"INVALID USER ID OR PASSWORD");
	        		
	      }
	    
	   /* if(k.equals(s3) && l.equals(s4))
	      {
	        	
	        	
	            //setVisible(true);
	            //badmin.addActionListener((e) ->{new StudentRegistration("title");});

	    new User("title");
	      }
	      else
	      {
	        		
	       		JOptionPane.showMessageDialog(this,"INVALID USER ID OR PASSWORD");
	        		
	      }*/
	    }
	    }catch(Exception e)
	    { JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
	    }
    }
	        	
	    void validuser()
	    { 
	    	
	    	String k=tid.getText().trim();
		    String l=tpass.getText().trim();
		    db.openStatement();
		    try{
		    	System.out.print("hhh");
		    	 if(buser.getText().equals("USER"))
		    	 {
		    		
		    		    rs1=db.getData("select * from login where userid='"+k+"' and Password='"+l+"'");
		    		    if(rs1.next())
		    		    {
		    		        rs1.close();
		    		        db.closeResultset();
		    		        this.setVisible(false);
		    		        JOptionPane.showMessageDialog(this,"Login Success") ;
		    		        new User("Welcome");

		    		    }
		    		   else
		    		      {
		    		        		
		    		       		JOptionPane.showMessageDialog(this,"INVALID USER ID OR PASSWORD");
		    		        		
		    		      }
		    		 
		    	 }
		    	
		    }catch(Exception e)
	          { JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
	          }
		  //  String s4="pass";
		    
		   /* userlist=UserDataReadWriteFromFile.readDataFromFile();
		    //ArrayList<Student> userlist;
		    data = new String[userlist.size()][15];
	 		int r=0;
		    int flag=0;
		    
		    	
		      
		    	for(Student re : userlist)
		 		{
		 			data[r][0]=re.getMobNo();
		 			data[r][1]=re.getName();
		 			data[r][2]=re.getPassword();
		 			data[r][3]=re.getAddress();
		 			data[r][4]=re.getNoStd();
		 			data[r][5]=re.getRateStd();
		 			data[r][6]=re.getNoIsd();
		 			data[r][7]=re.getRateIsd();
		 			data[r][8]=re.getNoLocal();
		 			data[r][9]=re.getRateLocal();
		 			data[r][10]=re.getNoSms();
		 			data[r][11]=re.getRateSms();
		 			data[r][12]=re.getServTax();
		 			data[r][13]=re.getUserId();
		 			data[r][14]=re.getTariff();
		 			
		 		
		    	
		 		 	if(k.equals(data[r][13])  && l.equals(data[r][2]))
		 		 	{
		        	
		 				flag=1;
		 				
		 		 	}r++;
		 		 	
		 		}		      
		    	if(flag==1)
	 		 	{
	        	
	 				new User("Welcome");
	 		 	}
		       else
			   {
			        		
			       		JOptionPane.showMessageDialog(this,"INVALID USER ID OR PASSWORD");
			        		
			   }
		 		
		    	 
		      
	    */
      
  
	    }
    public static void main(String[] args) {
    	new Login("Registration");
        
        // TODO code application logic here
    }
    
}
