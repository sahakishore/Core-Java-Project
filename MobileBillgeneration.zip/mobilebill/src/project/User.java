package project;
import dataconnect.*;
import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class User extends JFrame{
	private static final long serialVersionUID = 1L;
	private JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15;
	private JTextField tmobno,tuserid;
	private JPasswordField tpass;
	private JButton bgenerate;
	String s1,s2;
	String data[][];
	ArrayList<Student> list;
	Database db;
	ResultSet rs1;
	
	public User(String title)
	{	super(title);
		db=new Database();
		
		Container c=getContentPane();
		c.setLayout(new GridLayout(17,5));
		
		//tmobno=new JTextField(15);
		tuserid=new JTextField(15);
		tpass=new JPasswordField(15);
		Font f1=new Font("comic sans ms", Font.BOLD,14);
		l2=new JLabel(" Re-Enter Userid:");
		l2.setFont(f1);
		l2.setForeground(Color.RED);
		l3=new JLabel(" Re-Enter password:");
		l3.setFont(f1);
		l3.setForeground(Color.RED);
		
		
		bgenerate=new JButton("BILL");
		bgenerate.addActionListener((e) ->{generation();});
		
		c.add(l2);
		c.add(tuserid);
		c.add(l3);
		c.add(tpass);
		c.add(bgenerate);
		
		setSize(450,600);
		setLocation(450,10);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

}
	public String generation()
	{	db=new Database();
		int flag=0;
		s1=tuserid.getText().trim();
		s2=tpass.getText().trim();
		
		list = UserDataReadWriteFromFile.readDataFromFile();
		data = new String[list.size()][14];
	
		int r=0;
		for(Student re : list)
		{
			data[r][0]=re.getMobNo();
			data[r][1]=re.getName();
			data[r][2]=re.getPassword();
			data[r][3]=re.getAddress();
			data[r][4]=re.getNoStd();
			data[r][5]=re.getRateStd();
			data[r][6]=re.getNoIsd();
			data[r][7]=re.getRateIsd();
			data[r][8]=re.getNoLocal();
			data[r][9]=re.getRateLocal();
			data[r][10]=re.getNoSms();
			data[r][11]=re.getRateSms();
			data[r][12]=re.getServTax();
			data[r][13]=re.getUserId();
			
			try
			{
			    db.openStatement();
			    rs1 = db.getData("select * from login where userid='"+s1+"' and Password='"+s2+"'");
			    if((rs1.next() || s1.equals(data[r][13])) && (s2.equals(data[r][2])) )
			    {
				
				
				
			    	Float a1,a2,a3,a4,a5,a6,a7,a8,a9;
			    	float cal;
			    	float cal1;
			    	flag=1;
			    	a1=Float.parseFloat(data[r][4]);
			    	a2=Float.parseFloat(data[r][5]);
			    	a3=Float.parseFloat(data[r][6]);
			    	a4=Float.parseFloat(data[r][7]);
			    	a5=Float.parseFloat(data[r][8]);
			    	a6=Float.parseFloat(data[r][9]);
			    	a7=Float.parseFloat(data[r][10]);
			    	a8=Float.parseFloat(data[r][11]);
				 	a9=Float.parseFloat(data[r][12]);
				 	cal=((a1*a2)+(a3*a4)+(a5*a6)+(a7*a8));
				 	cal1=cal+((cal*a9)/100);
				
				 	rs1.close();
			        db.closeResultset();
			       // this.setVisible(false);
			        JOptionPane.showMessageDialog(this,"Searching Successful..");
			        JOptionPane.showMessageDialog(this,"Mobile no.: "+data[r][0]+"\nName: "+data[r][1]+"\nAddreess: "+data[r][3]+"\nNo. of Std: "+data[r][4]+"\nrate of Std: "+data[r][5]+"\nNo. of Isd: "+data[r][6]+"\nrate of Isd: "+data[r][7]+"\nNo. of Local: "+data[r][8]+"\nrate of Local: "+data[r][9]+"\nNo. of Sms: "+data[r][10]+"\nrate of Sms: "+data[r][11]+"\nrate of Service tax: "+data[r][12]+"\nYour total Bill Amount: "+cal1+"\nTHANK YOU FOR CHOOSING US");
			        break;
			    }
			    r++;
			
			    if(flag==0)
			    {
			    	JOptionPane.showMessageDialog(this,"Searching Unsuccessful..");
			    }
			   // return s1;
			}
			catch(Exception e)
		    { 
				JOptionPane.showMessageDialog(null, e.getMessage(),"Error in Database",1, null);
		    }
		   
		}
		 return s1;

	}
}
