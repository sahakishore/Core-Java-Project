package project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Insert extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private JButton binsert,bback,bbackmain;
	private JTextField tinsert,tmobno,tuserid,tname,tnolocal,tnostd,tnoisd,tratelocal,tratestd,trateisd,tnosms,tratesms,tstax;
	private JPasswordField tpass;
	private JTextArea taddress;
	private JComboBox tariff;
	//private JComboBox day,month,year;
	private JLabel l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17;
	String data[][];
	int a;
	ArrayList<Student> list;
	Student s;
	String t;
	public Insert(String title) {
		super(title);
		Container c=getContentPane();
		c.setLayout(new GridLayout(18,5));
		
		tmobno=new JTextField(15);
		tname=new JTextField(15);
		tpass=new JPasswordField(15);
		tnolocal=new JTextField(15);
		tnostd=new JTextField(15);
		tnoisd=new JTextField(15);
		tnosms=new JTextField(15);
		tratestd=new JTextField(15);
		tratelocal=new JTextField(15);
		trateisd=new JTextField(15);
		tratesms=new JTextField(15);
		tstax=new JTextField(15);
		tinsert=new JTextField(15);
		tuserid=new JTextField(15);
		taddress=new JTextArea(5,20);
		JScrollPane t=new JScrollPane(taddress);
		/*String dvalue[]=new String[31];
		for(int i=0;i<=30;i++)
		{
			dvalue[i]=String.valueOf(i+1);
			}
		day=new JComboBox(dvalue);
			
			String mvalue[]=new String[12];
			for(int i=0;i<=11;i++)
			{
				mvalue[i]=String.valueOf(i+1);
			}
		month=new JComboBox(mvalue);
		
		String yvalue[]=new String[17];
		int cnt=0;
		for(int i=2000;i<=2016;i++)
		{
			yvalue[cnt]=String.valueOf(i);
			cnt++;
		}
		year=new JComboBox(yvalue);
		JPanel cpanel=new JPanel();
		cpanel.add(day);
		cpanel.add(month);
		cpanel.add(year);*/
		
		String tvalue[]=new String[5];
		tvalue[0]="Select Item";
		tvalue[1]="1.2p/sec for Rs-165/-";
		tvalue[2]="1p/2sec for Rs-355/-";
		tvalue[3]="0.5/sec for Rs-289/-";
		tvalue[4]="0.2/sec for Rs-305/-";

		for(int i=0;i<=4;i++)
		{
			tvalue[i]=String.valueOf(tvalue[i]);
		}
		tariff=new JComboBox(tvalue);
		
		JPanel cpanel=new JPanel();
		cpanel.add(tariff);
		
		binsert=new JButton("Insert");
		binsert.addActionListener((e) ->{Insert();});
		
		Font f=new Font("Calibri (Body)", Font.BOLD,14);
		
		
		Font f1=new Font("comic sans ms", Font.BOLD,14);
		l2=new JLabel(" Enter Mob no:");
		l2.setFont(f1);
		l2.setForeground(Color.RED);
		
		l16=new JLabel(" Enter Userid:");
		l16.setFont(f1);
		l16.setForeground(Color.RED);
		
		l3=new JLabel(" Enter Name:");
		l3.setFont(f1);
		l3.setForeground(Color.RED);
		
		l4=new JLabel(" Enter Password:");
		l4.setFont(f1);
		l4.setForeground(Color.RED);
		
		l5=new JLabel(" Enter Address:");
		l5.setFont(f1);
		l5.setForeground(Color.RED);
		
		l6=new JLabel(" Enter No. of STD:");
		l6.setFont(f1);
		l6.setForeground(Color.RED);
		
		
		
		l7=new JLabel(" Enter rate of STD:");
		l7.setFont(f1);
		l7.setForeground(Color.RED);
		
		
		l8=new JLabel(" Enter No. of ISD:");
		l8.setFont(f1);
		l8.setForeground(Color.RED);
		
		
		
		l9=new JLabel(" Enter rate of ISD:");
		l9.setFont(f1);
		l9.setForeground(Color.RED);
		
		l10=new JLabel(" Enter No. of LOCAL:");
		l10.setFont(f1);
		l10.setForeground(Color.RED);
		
		
		
		l11=new JLabel(" Enter rate of LOCAL:");
		l11.setFont(f1);
		l11.setForeground(Color.RED);
		
		l12=new JLabel(" Enter No. of SMS:");
		l12.setFont(f1);
		l12.setForeground(Color.RED);
		
		
		
		l13=new JLabel(" Enter rate of SMS:");
		l13.setFont(f1);
		l13.setForeground(Color.RED);
		

		l14=new JLabel(" Enter Service Tax:");
		l14.setFont(f1);
		l14.setForeground(Color.RED);
		
		l17=new JLabel("Select Tariff Plan : ");
		l17.setFont(f);
		l17.setForeground(Color.RED);
		
		l15=new JLabel("Enter postion to be inserted");
		l15.setFont(f1);;
		l15.setForeground(Color.RED);
		
		bback=new JButton("Back");
		bback.addActionListener((e) ->{new Search("Account Operation");});
	    
		bbackmain=new JButton("Back to Home");
		bbackmain.addActionListener((e) ->{new StudentRegistration("Home page");});	
		
		c.add(l2);
		c.add(tmobno);
		c.add(l16);
		c.add(tuserid);
		c.add(l3);
		c.add(tname);
		c.add(l4);
		c.add(tpass);
		c.add(l5);
		c.add(taddress);
		c.add(l6);
		c.add(tnostd);
		c.add(l7);
		c.add(tratestd);
		c.add(l8);
		c.add(tnoisd);
		c.add(l9);
		c.add(trateisd);
		c.add(l10);
		c.add(tnolocal);
		c.add(l11);
		c.add(tratelocal);
		c.add(l12);
		c.add(tnosms);
		c.add(l13);
		c.add(tratesms);
		c.add(l14);
		c.add(tstax);
		c.add(l17);
		c.add(tariff);
		c.add(l15);
		c.add(tinsert);
		c.add(new JLabel(""));
		c.add(binsert);
		c.add(bback);
		c.add(bbackmain);
		
		setSize(450,500);
		setLocation(450,100);
		setResizable(false);
		setVisible(true);
	}
	public void createRegObj()
	{
		String mobno,password,name,address,ratelocal,rateisd,ratestd,ratesms,nostd,noisd,nolocal,nosms,servtax,userid,tar;
		
		mobno=tmobno.getText().trim();
		name=tname.getText().trim();
		password=tpass.getText().trim();
		address=taddress.getText().trim();
		ratelocal=tratelocal.getText().trim();
		rateisd=trateisd.getText().trim();
		ratestd=tratestd.getText().trim();
		ratesms=tratesms.getText().trim();
		nostd=tnostd.getText().trim();
		noisd=tnoisd.getText().trim();
		nolocal=tnolocal.getText().trim();
		nosms=tnosms.getText().trim();
		servtax="12.24";
		userid=tuserid.getText().trim();
		String t=(String)tariff.getSelectedItem();
		tar=t;
		
		s=new Student(mobno,name,password,address,ratelocal,rateisd,ratestd,ratesms,nostd,noisd,nolocal,nosms,servtax,userid,tar);
	}

	public void Insert()
	{
		
		list = UserDataReadWriteFromFile.readDataFromFile();
		if((tmobno.getText().length()==0) || (tuserid.getText().length()==0) || (tname.getText().length()==0) || (tpass.getText().length()==0) || (taddress.getText().length()==0) || (tratelocal.getText().length()==0) || (trateisd.getText().length()==0) || (tratestd.getText().length()==0) || (tratesms.getText().length()==0) || (tnostd.getText().length()==0) || (tnoisd.getText().length()==0) || (tnolocal.getText().length()==0) || (tnosms.getText().length()==0))
			JOptionPane.showMessageDialog(this,"Registration cann't be done");
	else
	{
		data = new String[list.size()][14];
		int r=0,i=0,pos=0,flag=0;
		for(Student re : list)
		{
			data[r][0]=re.getMobNo();
			data[r][1]=re.getName();
			data[r][2]=re.getPassword();
			data[r][3]=re.getAddress();
			data[r][4]=re.getNoStd();
			data[r][5]=re.getRateStd();
			data[r][6]=re.getNoIsd();
			data[r][7]=re.getRateIsd();
			data[r][8]=re.getNoLocal();
			data[r][9]=re.getRateLocal();
			data[r][10]=re.getNoSms();
			data[r][11]=re.getRateSms();
			data[r][12]=re.getServTax();
			data[r][13]=re.getUserId();
			
		r++;
	}
		a=Integer.parseInt(tinsert.getText().trim());
		createRegObj();
		for(i=0;i<list.size();i++){
			if(i==a)
			{
				flag=1;
				pos=a;
				break;
			}
		}
		
		//list.add(s);
		
	
		if(flag==1)
	{
	//	if((tmobno.getText().length()==0) || (tname.getText().length()==0) || (tpass.getText().length()==0) || (taddress.getText().length()==0) || (tratelocal.getText().length()==0) || (trateisd.getText().length()==0) || (tratestd.getText().length()==0) || (tratesms.getText().length()==0) || (tnostd.getText().length()==0) || (tnoisd.getText().length()==0) || (tnolocal.getText().length()==0) || (tnosms.getText().length()==0) || (tstax.getText().length()==0))
		//	JOptionPane.showMessageDialog(this,"Registration cann't be done");
		//else
		//{
		list.add(a,s);
		UserDataReadWriteFromFile.writeDatatoFile(list);
		JOptionPane.showMessageDialog(this,"Insertion Successful...");
		//}
	}
		else
		{
			JOptionPane.showMessageDialog(this,"Insertion not possible...");
		}
	}
		
	}

}
	