package project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
 
public class Delete extends JFrame
{
	private JLabel l12,l13;
	private JTextField tmobno;
	private JButton bdelete1,bback,bbackmain;
	
	String mobno;
	String data[][];
	ArrayList<Student> list;
	Student s;
	
	public Delete(String title)
	{
		super(title);
		
		Container c=getContentPane();
		c.setLayout(new GridLayout(20,2));

		tmobno=new JTextField(20);
		
		bdelete1=new JButton("Delete");
		bdelete1.addActionListener((e) ->{Deletion();});
		
		
		bback=new JButton("Back");
		bback.addActionListener((e) ->{new Search("Account Operation");});

		bbackmain=new JButton("Back to Home");
		bbackmain.addActionListener((e) ->{new StudentRegistration("Home page");});
		Font f=new Font("Calibri (Body)", Font.BOLD,14);
		
		
		Font f1=new Font("Times New Roman",Font.BOLD,16);
		l12=new JLabel("DELETE DETAILs");
		l12.setFont(f1);;
		l12.setForeground(Color.BLUE);
		
		Font f2=new Font("Calibri (Body)", Font.BOLD,14);
		l13=new JLabel(" Enter Mobile No:");
		l13.setFont(f2);
		l13.setForeground(Color.RED);
		
		c.add(l12);
	    c.add(new JLabel(""));
		c.add(l13);c.add(tmobno);
		
		c.add(bdelete1);
		c.add(bback);
		c.add(bbackmain);
		
		  setSize(450,900);
	      setLocation(500,50);
	      setResizable(false);
	      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      setVisible(true);
		
	}
			private void Delete() {
		// TODO Auto-generated method stub
		
	}
	public void Deletion()
			{
				int flag=0;
				mobno=tmobno.getText().trim();
		  		list = UserDataReadWriteFromFile.readDataFromFile();
		  		data = new String[list.size()][13];
		  		int r=0;
		  		for(Student re:list)
		  		{
		  			data[r][0]=re.getMobNo();
					data[r][1]=re.getName();
					data[r][2]=re.getPassword();
					data[r][3]=re.getAddress();
					data[r][4]=re.getNoStd();
					data[r][5]=re.getRateStd();
					data[r][6]=re.getNoIsd();
					data[r][7]=re.getRateIsd();
					data[r][8]=re.getNoLocal();
					data[r][9]=re.getRateLocal();
					data[r][10]=re.getNoSms();
					data[r][11]=re.getRateSms();
					data[r][12]=re.getServTax();
		  			
		  			if((mobno).equals(data[r][0]))
		  			{
		  			
		  				flag=1;
		  				//for (int i = 0; i <userlist.size(); i++)
		  				//{
		  				list.remove(r);
		  				
		  				JOptionPane.showMessageDialog(this,"delete successful...");
		  				break;
		  				
		  			}
		  		
		  			r++;
		  		}UserDataReadWriteFromFile.writeDatatoFile(list);
		  			if(flag==0)
		  			{
		  				JOptionPane.showMessageDialog(this,"delete unsuccessful...");
		  			}
		  			
		  		}
		  		
	/*public Delete()
	{
		super("delete");
		ArrayList<Student> list2;
		try
		{
			list2 = UserDataReadWriteFromFile.readDataFromFile();
			
			String searchType1=JOptionPane.showInputDialog(null,"enter the roll number you want to delete");
			
			for(int i=0; i<list2.size(); i++)
			{
				if (searchType1.equalsIgnoreCase(list2.get(i).getMobNo()))
				{
					list2.remove(i);
					JOptionPane.showMessageDialog(null, "All the information are deleted");
					UserDataReadWriteFromFile.writeDatatoFile(list2);
					break;
				}
					
	}
		}
catch(Exception e)
{
	System.out.println(e);
}*/
}
