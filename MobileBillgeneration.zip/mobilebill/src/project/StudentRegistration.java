package project;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class StudentRegistration extends JFrame
{
	private static final long serialVersionUID = 1L;
	private JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16;
	private JTextField tmobno,tuserid,tname,tnolocal,tnostd,tnoisd,tratelocal,tratestd,trateisd,tnosms,tratesms,tstax;
	private JPasswordField tpass;
	private JTextArea taddress;
	private JComboBox tariff;
	private JComboBox day,month,year;
	private JButton bregister,bshowall,bclearall,bsearch,blogout;
	private String sysdate,systime;
	String ta;
	private final JMenuBar jmenubar;
	private final JMenu jmenu;
	private final JMenuItem jmenuregister,jmenushowall;
	
	ArrayList<Student> userlist;
	
	Student s;
	
	public StudentRegistration(String title)
	{
		super(title);
		
		Container c=getContentPane();
		c.setLayout(new GridLayout(20,20));
		
		tmobno=new JTextField(10);
		tname=new JTextField(10);
		tpass=new JPasswordField(10);
		tnolocal=new JTextField(1);
		tnostd=new JTextField(10);
		tnoisd=new JTextField(10);
		tnosms=new JTextField(10);
		tratestd=new JTextField(10);
		tratelocal=new JTextField(10);
		trateisd=new JTextField(10);
		tratesms=new JTextField(10);
		tstax=new JTextField(10);
		tuserid=new JTextField(10);
		
		taddress=new JTextArea(5,10);
		JScrollPane t=new JScrollPane(taddress);
		
		String tvalue[]=new String[5];
		tvalue[0]="Select Item";
		tvalue[1]="1.2p/sec for Rs-165/-";
		tvalue[2]="1p/2sec for Rs-355/-";
		tvalue[3]="0.5/sec for Rs-289/-";
		tvalue[4]="0.2/sec for Rs-305/-";
		
		for(int i=0;i<=4;i++)
		{
			tvalue[i]=String.valueOf(tvalue[i]);
		}
		tariff=new JComboBox(tvalue);
		
		//tariff.setBounds(413,11,147,20);
		
		//Object selectedIndex1=tariff.getSelectedItem();
		//tariff.getSelectedItem();
		//selectedIndex1=tariff.getSelectedItem();
		//String selectedindex2=toString(selectedIndex1);
		//System.out.println(" "+selectedindex2);
		JPanel cpanel=new JPanel();
		cpanel.add(tariff);
		
		/*String dvalue[]=new String[32];
		dvalue[0]="Select Date";
		for(int i=1;i<=31;i++)
		{
			dvalue[i]=String.valueOf(i);
		}
		day=new JComboBox(dvalue);
		
		String mvalue[]=new String[13];
		/*for(int i=0;i<=11;i++)
		{
			mvalue[i]=String.valueOf(i+1);
		}*/
/*		{
			mvalue[0]="Select Month";
			mvalue[1]="January";
			mvalue[2]="February";
			mvalue[3]="March";
			mvalue[4]="April";
			mvalue[5]="May";
			mvalue[6]="June";
			mvalue[7]="July";
			mvalue[8]="August";
			mvalue[9]="September";
			mvalue[10]="October";
			mvalue[11]="November";
			mvalue[12]="December";
		}
		month=new JComboBox(mvalue);
		
		String yvalue[]=new String[28];
		yvalue[0]="Select Year";
		int cnt=1;
		for(int i=1990;i<=2016;i++)
		{
			yvalue[cnt]=String.valueOf(i);
			cnt++;
		}
		year=new JComboBox(yvalue);
		
		JPanel cpanel=new JPanel();
		cpanel.add(day);
		cpanel.add(month);
		cpanel.add(year);*/
		//String tariffplan=String tvalue[i].getSelectedtext();
		
		bregister=new JButton("Register");
		bregister.addActionListener((e) ->{addInformation();});
		
		bshowall=new JButton("Show All");
		bshowall.addActionListener((e) ->{new DisplayAllData();});
		
		
		bsearch=new JButton("Operate Account");
		bsearch.addActionListener((e) ->{new Search("Acoount Operation");});
		
		
		bclearall=new JButton("Reset All");
		bclearall.addActionListener((e) ->{resetFrame();});
		
		blogout=new JButton("Log out");
		blogout.addActionListener((e) ->{new Login("Log in");});
        
		
		this.dispose();
		//bsearch=new JButton("Search");
		//bsearch.addActionListener((e) ->{new Search("Searching");});
		
		Font f=new Font("Copperplate Gothic Bold", Font.BOLD,15);
		l1=new JLabel("Student  Registration",SwingConstants.CENTER);
		l1.setFont(f);
		l1.setForeground(Color.BLUE);
		
		Font f1=new Font("comic sans ms", Font.BOLD,14);
		l2=new JLabel(" Enter Mob no:");
		l2.setFont(f1);
		l2.setForeground(Color.RED);
		
		
		
		l3=new JLabel(" Enter Name:");
		l3.setFont(f1);
		l3.setForeground(Color.RED);
		
		l4=new JLabel(" Enter Password:");
		l4.setFont(f1);
		l4.setForeground(Color.RED);
		
		l5=new JLabel(" Enter Address:");
		l5.setFont(f1);
		l5.setForeground(Color.RED);
		
		l6=new JLabel(" Enter No. of STD:");
		l6.setFont(f1);
		l6.setForeground(Color.RED);
		
		
		
		l7=new JLabel(" Enter rate of STD:");
		l7.setFont(f1);
		l7.setForeground(Color.RED);
		
		
		l8=new JLabel(" Enter No. of ISD:");
		l8.setFont(f1);
		l8.setForeground(Color.RED);
		
		
		
		l9=new JLabel(" Enter rate of ISD:");
		l9.setFont(f1);
		l9.setForeground(Color.RED);
		
		l10=new JLabel(" Enter No. of LOCAL:");
		l10.setFont(f1);
		l10.setForeground(Color.RED);
		
		
		
		l11=new JLabel(" Enter rate of LOCAL:");
		l11.setFont(f1);
		l11.setForeground(Color.RED);
		
		l12=new JLabel(" Enter No. of SMS:");
		l12.setFont(f1);
		l12.setForeground(Color.RED);
		
		
		
		l13=new JLabel(" Enter rate of SMS:");
		l13.setFont(f1);
		l13.setForeground(Color.RED);
		

		l14=new JLabel(" Enter Service Tax:");
		l14.setFont(f1);
		l14.setForeground(Color.RED);
		
		l15=new JLabel("Select Tariff Plan : ");
		l15.setFont(f);
		l15.setForeground(Color.RED);
		

		l16=new JLabel(" Enter Userid:");
		l16.setFont(f1);
		l16.setForeground(Color.RED);
		
		
		
	/*	l6=new JLabel(" Select DOB:");
		l6.setFont(f1);
		l6.setForeground(Color.RED);*/
		
		//Java 8 new class
		/*LocalDate today=LocalDate.now();
		int day=today.getDayOfMonth();
		int month=today.getMonthValue();
		int year=today.getYear();
	
		sysdate=day+"/"+month+"/"+year;
		l7=new JLabel(" Current Date:"+sysdate);
		
		//Java 8 new class
		LocalTime time=LocalTime.now();
		int hr=time.getHour();
		int min=time.getMinute();
		int sec=time.getSecond();
		
		systime=hr+":"+min+":"+sec;
		l8=new JLabel(" Current Time:"+systime);*/
		
		
		c.add(l2);c.add(tmobno);
		c.add(l3);c.add(tname);
		c.add(l4);c.add(tpass);
		c.add(l5);c.add(t);
		c.add(l6);c.add(tnostd);
		c.add(l7);c.add(tratestd);
		c.add(l8);c.add(tnoisd);
		c.add(l9);c.add(trateisd);
		c.add(l10);c.add(tnolocal);
		c.add(l11);c.add(tratelocal);
		c.add(l12);c.add(tnosms);
		c.add(l13);c.add(tratesms);
		c.add(l14);c.add(tstax);
		c.add(l15);c.add(tariff);
		c.add(l16);c.add(tuserid);
		//c.add(l6);c.add(cpanel);
		
		//c.add(l7);
		//c.add(l8);
		
		
		c.add(bclearall);
		c.add(bregister);
		c.add(bshowall);
		c.add(bsearch);
		c.add(blogout);
		jmenubar=new JMenuBar();
		
		jmenu=new JMenu("OPTION");
		jmenu.setMnemonic(KeyEvent.VK_O);
		
		jmenuregister=new JMenuItem("Register");
		jmenuregister.setMnemonic(KeyEvent.VK_R);
		jmenuregister.setToolTipText("Registration..");
		jmenuregister.addActionListener((e) -> {addInformation();});
		
		jmenushowall=new JMenuItem("Show All");
		jmenushowall.setMnemonic(KeyEvent.VK_S);
		jmenushowall.addActionListener((e) ->{new DisplayAllData();});
		
		jmenu.add(jmenuregister);
		jmenu.add(jmenushowall);
		
		jmenubar.add(jmenu);
		setJMenuBar(jmenubar);
		
		setSize(450,600);
		setLocation(450,10);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public void createRegObj()
	{
		String mobno,password,name,address,ratelocal,rateisd,ratestd,ratesms,nostd,noisd,nolocal,nosms,servtax,userid,tar;
		Object selectedIndex1;
		//int selectedIndex1;
	//	String selectedIndex2=Integer.toString(selectedIndex1);
		mobno=tmobno.getText().trim();
		name=tname.getText().trim();
		password=tpass.getText().trim();
		address=taddress.getText().trim();
		ratelocal=tratelocal.getText().trim();
		rateisd=trateisd.getText().trim();
		ratestd=tratestd.getText().trim();
		ratesms=tratesms.getText().trim();
		nostd=tnostd.getText().trim();
	
		noisd=tnoisd.getText().trim();
		nolocal=tnolocal.getText().trim();
		nosms=tnosms.getText().trim();
		servtax="12.24";
		userid=tuserid.getText().trim();
		String t=(String)tariff.getSelectedItem();
		tar=t;
		//selectedIndex1=tariff.getSelectedItem();
		
	//	selectedIndex2=selectedIndex2.getSe().trim();
		
		s=new Student(mobno,name,password,address,ratelocal,rateisd,ratestd,ratesms,nostd,noisd,nolocal,nosms,servtax,userid,tar);
	}
	
	public void addInformation()
	{
		createRegObj();
		String l=new String ();
		
		userlist=UserDataReadWriteFromFile.readDataFromFile();
		if((tmobno.getText().length()==0) || (tuserid.getText().length()==0) || (tname.getText().length()==0) || (tpass.getText().length()==0) || (taddress.getText().length()==0) || (tratelocal.getText().length()==0) || (trateisd.getText().length()==0) || (tratestd.getText().length()==0) || (tratesms.getText().length()==0) || (tnostd.getText().length()==0) || (tnoisd.getText().length()==0) || (tnolocal.getText().length()==0) || (tnosms.getText().length()==0))
			JOptionPane.showMessageDialog(this,"Registration cann't be done");
		else
		{
			
		
		userlist.add(s);
		UserDataReadWriteFromFile.writeDatatoFile(userlist);
		JOptionPane.showMessageDialog(this,"Registration Successful..");
		
		resetFrame();
		}
	}
	
	public void resetFrame()
	{
		this.dispose();
		new StudentRegistration("Registration");
	}
	
	/*void valid()
	{
		createRegObj();
		String l=new String ();
		int flag=0;
		
		userlist=UserDataReadWriteFromFile.readDataFromFile();
		if(tmobno.getText().equals(l) && tname.getText().equals(l) && tpass.getText().equals(l) && taddress.getText().equals(l) && tratelocal.getText().equals(l) && trateisd.getText().equals(l) && tratestd.getText().equals(l) && tratesms.getText().equals(l) && tnostd.getText().equals(l) && tnoisd.getText().equals(l) && tnolocal.getText().equals(l) && tnosms.getText().equals(l) && tstax.getText().equals(l))
		{
			flag=1;
			new addInformation();
			
		}
		else
		{
			flag=0;
			
		}
	}*/
	
	/*public static void main(String args[])
	{
		new StudentRegistration("Registration");
	}*/
}

