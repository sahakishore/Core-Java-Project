package project;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Search extends JFrame
{
	private static final long serialVersionUID = 1L;
	private JLabel l1,l2,l3,l4,l5;
	private JTextField tmobno;
	
	private JButton bsearch,bupdate,bdelete,binsert,bclearall,bback;
	private String sysdate,systime;
	String mobno;
	String data[][];
	ArrayList<Student> list;
	
	public Search(String title)
	{
		super(title);
		
		Container c=getContentPane();
		c.setLayout(new GridLayout(12,5));
		
		tmobno=new JTextField(15);
		
		bsearch=new JButton("Search");
		bsearch.addActionListener((e) ->{Find();});
		
		bupdate=new JButton("Update");
		bupdate.addActionListener((e) ->{new Update("Update Record");});
		
		bdelete=new JButton("Delete");
		bdelete.addActionListener((e) ->{new Delete(mobno);});
		
		binsert=new JButton("Insert");
		binsert.addActionListener((e) ->{new Insert("Insert Record After");});
		
		bclearall=new JButton("Reset All");
		bclearall.addActionListener((e) ->{resetFrame();});
		
		Font f=new Font("Calibri (Body)", Font.BOLD,14);
		l1=new JLabel(" Enter Mobile No:");
		l1.setFont(f);
		l1.setForeground(Color.RED);
		
		bback=new JButton("Back");
		bback.addActionListener((e) ->{new StudentRegistration("REGISTRATION");});
		
		//Java 8 new class
		/*LocalDate today=LocalDate.now();
		int day=today.getDayOfMonth();
		int month=today.getMonthValue();
		int year=today.getYear();
		
		sysdate=day+"/"+month+"/"+year;
		l2=new JLabel(" Current Date:"+sysdate);
				
		//Java 8 new class
		LocalTime time=LocalTime.now();
		int hr=time.getHour();
		int min=time.getMinute();
		int sec=time.getSecond();
				
		systime=hr+":"+min+":"+sec;
		l3=new JLabel(" Current Time:"+systime);*/
		
		c.add(new JLabel(""));
		c.add(l1);c.add(tmobno);
		//c.add(l2);
		//c.add(l3);
		c.add(new JLabel(""));
		c.add(bsearch);//c.add(new JLabel(""));
		c.add(bupdate);c.add(bdelete);
		c.add(binsert);c.add(bclearall);
		c.add(bback);
		
		setSize(450,500);
		setLocation(450,100);
		setResizable(false);
		setVisible(true);
	}
	
	public void resetFrame()
	{
		this.dispose();
		new Search("Searching");
	}
	
	
	
	public String Find()
	{
		int flag=0;
		mobno=tmobno.getText().trim();
		list = UserDataReadWriteFromFile.readDataFromFile();
		data = new String[list.size()][14];
		int r=0;
		for(Student re : list)
		{
			data[r][0]=re.getMobNo();
			data[r][1]=re.getName();
			data[r][2]=re.getPassword();
			data[r][3]=re.getAddress();
			data[r][4]=re.getNoStd();
			data[r][5]=re.getRateStd();
			data[r][6]=re.getNoIsd();
			data[r][7]=re.getRateIsd();
			data[r][8]=re.getNoLocal();
			data[r][9]=re.getRateLocal();
			data[r][10]=re.getNoSms();
			data[r][11]=re.getRateSms();
			data[r][12]=re.getServTax();
			data[r][13]=re.getTariff();
			
			if((mobno).equals(data[r][0]))
			{
				flag=1;
				JOptionPane.showMessageDialog(this,"Searching Successful..");
				JOptionPane.showMessageDialog(this,"Mobile no.: "+data[r][0]+"\nName: "+data[r][1]+"\nPassword: "+data[r][2]+"\nAddreess: "+data[r][3]+"\nNo. of Std: "+data[r][4]+"\nrate of Std: "+data[r][5]+"\nNo. of Isd: "+data[r][6]+"\nrate of Isd: "+data[r][7]+"\nNo. of Local: "+data[r][8]+"\nrate of Local: "+data[r][9]+"\nNo. of Sms: "+data[r][10]+"\nrate of Sms: "+data[r][11]+"\rate of Service tax: "+data[r][12]+"\nTariff plan: "+data[r][13]);
				break;
			}
			r++;
		}
		if(flag==0)
		{
			JOptionPane.showMessageDialog(this,"Searching Unsuccessful..");
		}
		return mobno;
	}
	
	public void Delete(String mob)
	{
		
	}
}


