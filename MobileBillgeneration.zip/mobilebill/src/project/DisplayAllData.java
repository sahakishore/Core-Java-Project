package project;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.BorderLayout;
import java.awt.Container;
import java.util.ArrayList;

public class DisplayAllData extends JFrame 
{
	private static final long serialVersionUID = 1L;

	public DisplayAllData()
	{
		super("Display All");
		String heading[]={"MobNo","Name","Password","Address","STD NO","STD RATE","ISD NO.","ISD RATE","LOCAL NO","LOCAL RATE","SMS NO.","SMS RATE","SERVICE TAX","USER ID","TARIFF PLAN"};
		String data[][];
		ArrayList<Student> list;
		try
		{  
			list = UserDataReadWriteFromFile.readDataFromFile();
			
			data = new String[list.size()][15];
			
			int r=0;
			for(Student re : list)
			{
				data[r][0]=re.getMobNo();
				data[r][1]=re.getName();
				data[r][2]=re.getPassword();
				data[r][3]=re.getAddress();
				data[r][4]=re.getNoStd();
				data[r][5]=re.getRateStd();
				data[r][6]=re.getNoIsd();
				data[r][7]=re.getRateIsd();
				data[r][8]=re.getNoLocal();
				data[r][9]=re.getRateLocal();
				data[r][10]=re.getNoSms();
				data[r][11]=re.getRateSms();
				data[r][12]=re.getServTax();
				data[r][13]=re.getUserId();
				data[r][14]=re.getTariff();
				
				r++;
			}
			
			Container con=getContentPane();
			con.setLayout(new BorderLayout());
			
			JTable datatable=new JTable(data, heading);
			JScrollPane jsp=new JScrollPane(datatable);
			
			con.add(new JLabel("All Registration Details"),BorderLayout.NORTH);
			con.add(jsp,BorderLayout.CENTER);
			
			setSize(850, 300);
			setLocation(200, 200);
			setVisible(true);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
