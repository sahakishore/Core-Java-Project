package project;
import java.io.Serializable;

public class Student implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String mobno;
	private String password;
	private String name;
	private String address;
	private String ratelocal;
	private String rateisd;
	private String ratestd;
	private String ratesms;
	private String nostd;
	private String noisd;
	private String nolocal;
	private String nosms;
	private String servtax;
	
	private String userid;
	private String tar;
	private String com;
	public Student(String mobno,String name,String password,String address,String ratelocal,String rateisd,String ratestd,String ratesms,String nostd,String noisd,String nolocal,String nosms,String servtax,String userid,String tar)
	{
		super();
		this.mobno=mobno;
		this.name=name;
		this.password=password;
		this.address=address;
	    this.ratelocal=ratelocal;
	    this.rateisd=rateisd;
		this.ratestd=ratestd;
		this.ratesms=ratesms;
		this.nostd=nostd;
		this.noisd=noisd;
		this.nolocal=nolocal;
		this.nosms=nosms;
		this.servtax=servtax;
		//this.tariff=tariff;
		this.userid=userid;
		this.tar=tar;
	}
	
	public Student()
	{
		
	}
	
	public String getMobNo()
	{
		return mobno;
	}
	
	public void setMobNo(String mobno)
	{
		this.mobno=mobno;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	public void setPassword(String password)
	{
		this.password=password;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public String getAddress()
	{
		return address;
	}
	
	public void setAddress(String address)
	{
		this.address=address;
	}
	
	public String getNoStd()
	{
		return nostd;
	}
	
	public void setNoStd(String nostd)
	{
		this.nostd=nostd;
	}
	
	public String getNoIsd()
	{
		return noisd;
	}
	
	public void setNoIsd(String noisd)
	{
		this.noisd=noisd;
	}
	public String getNoLocal()
	{
		return nolocal;
	}
	
	public void setNoLocal(String nolocal)
	{
		this.nolocal=nolocal;
	}
	public String getNoSms()
	{
		return nosms;
	}
	
	public void setNoSms(String nosms)
	{
		this.nosms=nosms;
	}
	public String getRateStd()
	{
		return ratestd;
	}
	
	public void setRateStd(String ratestd)
	{
		this.ratestd=ratestd;
	}
	public String getRateIsd()
	{
		return rateisd;
	}
	
	public void setRateIsd(String rateisd)
	{
		this.rateisd=rateisd;
	}
	public String getRateLocal()
	{
		return ratelocal;
	}
	
	public void setRateLocal(String ratelocal)
	{
		this.ratelocal=ratelocal;
	}
	public String getRateSms()
	{
		return ratesms;
	}
public void setRateSms(String ratesms)	
{
	this.ratesms=ratesms;
}

public String getServTax()
{
	return servtax;
}
public void setServTax(String servtax)	
{
this.servtax=servtax;
}

public String getUserId()
{
	return userid;
}
public void setUserId(String userid)	
{
this.userid=userid;
}

public String getTariff()
{
	return tar;
}

public void setTariff(String tar)
{
	this.tar=tar;
}

}


