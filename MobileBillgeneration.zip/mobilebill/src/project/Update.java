package project;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Update extends JFrame
{
	private static final long serialVersionUID = 1L;
	private JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16;
	private JTextField tmobno,tuserid,tname,tnolocal,tnostd,tnoisd,tratelocal,tratestd,trateisd,tnosms,tratesms,tstax;
	private JPasswordField tpass;
	private JTextArea taddress;
	private JButton bback,bbackmain;
	private JComboBox tariff;
	Student s;
	String ta;
	
	//private JComboBox day,month,year;
	private JButton bupdate,bclearall,bshowall;
	private String sysdate,systime;
	String mobno,userid;
	String data[][];
	ArrayList<Student> list;
	
	public Update(String title)
	{
		super(title);
		
		Container c=getContentPane();
		c.setLayout(new GridLayout(20,5));
		
		tmobno=new JTextField(15);
		tname=new JTextField(15);
		tpass=new JPasswordField(15);
		tnolocal=new JTextField(15);
		tnostd=new JTextField(15);
		tnoisd=new JTextField(15);
		tnosms=new JTextField(15);
		tratestd=new JTextField(15);
		tratelocal=new JTextField(15);
		trateisd=new JTextField(15);
		tratesms=new JTextField(15);
		tstax=new JTextField(15);
		tuserid=new JTextField(15);
		
		taddress=new JTextArea(5,20);
		JScrollPane t=new JScrollPane(taddress);
		
		String tvalue[]=new String[5];
		tvalue[0]="Select Item";
		tvalue[1]="1.2p/sec for Rs-165/-";
		tvalue[2]="1p/2sec for Rs-355/-";
		tvalue[3]="0.5/sec for Rs-289/-";
		tvalue[4]="0.2/sec for Rs-305/-";

		/*for(int i=0;i<=5;i++)
		{
			tvalue[i]=String.valueOf(tvalue[i]);
		}
		*/
		tariff=new JComboBox(tvalue);
		
		/*String dvalue[]=new String[32];
		dvalue[0]="Select Date";
		for(int i=1;i<=31;i++)
		{
			dvalue[i]=String.valueOf(i);
		}
		day=new JComboBox(dvalue);
		
		String mvalue[]=new String[13];
		/*for(int i=0;i<=11;i++)
		{
			mvalue[i]=String.valueOf(i+1);
		}*/
		/*{
			mvalue[0]="Select Month";
			mvalue[1]="January";
			mvalue[2]="February";
			mvalue[3]="March";
			mvalue[4]="April";
			mvalue[5]="May";
			mvalue[6]="June";
			mvalue[7]="July";
			mvalue[8]="August";
			mvalue[9]="September";
			mvalue[10]="October";
			mvalue[11]="November";
			mvalue[12]="December";
		}
		month=new JComboBox(mvalue);
		
		String yvalue[]=new String[28];
		yvalue[0]="Select Year";
		int cnt=1;
		for(int i=1990;i<=2016;i++)
		{
			yvalue[cnt]=String.valueOf(i);
			cnt++;
		}
		year=new JComboBox(yvalue);
		
		JPanel cpanel=new JPanel();
		cpanel.add(day);
		cpanel.add(month);
		cpanel.add(year);*/
		
		
		bupdate=new JButton("Update");
		bupdate.addActionListener((e) ->{Update();});
		
		bclearall=new JButton("Reset All");
		bclearall.addActionListener((e) ->{resetFrame();});
		
		bshowall=new JButton("Show All");
		bshowall.addActionListener((e) ->{new DisplayAllData();});
		
		Font f1=new Font("comic sans ms", Font.BOLD,14);
		l2=new JLabel(" Enter Mob no:");
		l2.setFont(f1);
		l2.setForeground(Color.RED);
		
		l15=new JLabel(" Enter User Id:");
		l15.setFont(f1);
		l15.setForeground(Color.RED);
		
		l3=new JLabel(" Enter Name:");
		l3.setFont(f1);
		l3.setForeground(Color.RED);
		
		l4=new JLabel(" Enter Password:");
		l4.setFont(f1);
		l4.setForeground(Color.RED);
		
		l5=new JLabel(" Enter Address:");
		l5.setFont(f1);
		l5.setForeground(Color.RED);
		
		l6=new JLabel(" Enter No. of STD:");
		l6.setFont(f1);
		l6.setForeground(Color.RED);
		
		
		
		l7=new JLabel(" Enter rate of STD:");
		l7.setFont(f1);
		l7.setForeground(Color.RED);
		
		
		l8=new JLabel(" Enter No. of ISD:");
		l8.setFont(f1);
		l8.setForeground(Color.RED);
		
		
		
		l9=new JLabel(" Enter rate of ISD:");
		l9.setFont(f1);
		l9.setForeground(Color.RED);
		
		l10=new JLabel(" Enter No. of LOCAL:");
		l10.setFont(f1);
		l10.setForeground(Color.RED);
		
		
		
		l11=new JLabel(" Enter rate of LOCAL:");
		l11.setFont(f1);
		l11.setForeground(Color.RED);
		
		l12=new JLabel(" Enter No. of SMS:");
		l12.setFont(f1);
		l12.setForeground(Color.RED);
		
		
		
		l13=new JLabel(" Enter rate of SMS:");
		l13.setFont(f1);
		l13.setForeground(Color.RED);
		

		l14=new JLabel(" Enter Service Tax:");
		l14.setFont(f1);
		l14.setForeground(Color.RED);
		
		

		l16=new JLabel("Select Tariff Plan : ");
		l16.setFont(f1);
		l16.setForeground(Color.RED);
		
		
		bback=new JButton("Back");
		bback.addActionListener((e) ->{new Search("Account operation");});
		
		bbackmain=new JButton("Back to Home");
		bbackmain.addActionListener((e) ->{new StudentRegistration("Home page");});
		//Java 8 new class
		/*LocalDate today=LocalDate.now();
		int day=today.getDayOfMonth();
		int month=today.getMonthValue();
		int year=today.getYear();
		
		sysdate=day+"/"+month+"/"+year;
		l5=new JLabel(" Current Date:"+sysdate);
				
		//Java 8 new class
		LocalTime time=LocalTime.now();
		int hr=time.getHour();
		int min=time.getMinute();
		int sec=time.getSecond();
				
		systime=hr+":"+min+":"+sec;
		l6=new JLabel(" Current Time:"+systime);*/
		
		c.add(l2);
		c.add(tmobno);
		c.add(l15);
		c.add(tuserid);
		c.add(l3);
		c.add(tname);
		c.add(l4);
		c.add(tpass);
		c.add(l5);
		c.add(taddress);
		c.add(l6);
		c.add(tnostd);
		c.add(l7);
		c.add(tratestd);
		c.add(l8);
		c.add(tnoisd);
		c.add(l9);
		c.add(trateisd);
		c.add(l10);
		c.add(tnolocal);
		c.add(l11);
		c.add(tratelocal);
		c.add(l12);
		c.add(tnosms);
		c.add(l13);
		c.add(tratesms);
		c.add(l14);
		c.add(tstax);
		c.add(l16);
		c.add(tariff);
		
		c.add(bupdate);c.add(bclearall);
		c.add(bshowall);c.add(bback);
		       c.add(bbackmain);

		
		setSize(600,800);
		setLocation(450,100);
		setResizable(false);
		setVisible(true);
	}
	
	public void resetFrame()
	{
		this.dispose();
		new Update("Update Record");
	}
	
	public void createRegObj()
	{
		String mobno,password,name,address,ratelocal,rateisd,ratestd,ratesms,nostd,noisd,nolocal,nosms,servtax,userid,tar;
		
		mobno=tmobno.getText().trim();
		name=tname.getText().trim();
		password=tpass.getText().trim();
		address=taddress.getText().trim();
		ratelocal=tratelocal.getText().trim();
		rateisd=trateisd.getText().trim();
		ratestd=tratestd.getText().trim();
		ratesms=tratesms.getText().trim();
		nostd=tnostd.getText().trim();
		noisd=tnoisd.getText().trim();
		nolocal=tnolocal.getText().trim();
		nosms=tnosms.getText().trim();
		servtax="12.24";
		userid=tuserid.getText().trim();
		String t=(String)tariff.getSelectedItem();
		tar=t;
		s=new Student(mobno,name,password,address,ratelocal,rateisd,ratestd,ratesms,nostd,noisd,nolocal,nosms,servtax,userid,tar);
	}
	
	
	
	public void Update()
	{
		int flag=0;
		createRegObj();
		
		//mobno=tmobno.getText().trim();
		list = UserDataReadWriteFromFile.readDataFromFile();
		if((tmobno.getText().length()==0) || (tuserid.getText().length()==0) || (tname.getText().length()==0) || (tpass.getText().length()==0) || (taddress.getText().length()==0) || (tratelocal.getText().length()==0) || (trateisd.getText().length()==0) || (tratestd.getText().length()==0) || (tratesms.getText().length()==0) || (tnostd.getText().length()==0) || (tnoisd.getText().length()==0) || (tnolocal.getText().length()==0) || (tnosms.getText().length()==0))
			JOptionPane.showMessageDialog(this,"Please fill all the input field to update account");
	else
	{
		data = new String[list.size()][15];
		int r=0;
		//String pass,name,address,dob;
		
		/*name=tname.getText().trim();
		pass=tpass.getText().trim();
		address=taddress.getText().trim();*/
		
		String mobno,password,name,address,ratelocal,rateisd,ratestd,ratesms,nostd,noisd,nolocal,nosms,servtax,userid,tar;
		
		mobno=tmobno.getText().trim();
		name=tname.getText().trim();
		password=tpass.getText().trim();
		address=taddress.getText().trim();
		ratelocal=tratelocal.getText().trim();
		rateisd=trateisd.getText().trim();
		ratestd=tratestd.getText().trim();
		ratesms=tratesms.getText().trim();
		nostd=tnostd.getText().trim();
		noisd=tnoisd.getText().trim();
		nolocal=tnolocal.getText().trim();
		nosms=tnosms.getText().trim();
		servtax=tstax.getText().trim();
		userid=tuserid.getText().trim();
		String t=(String)tariff.getSelectedItem();
		tar=t; 
		
		
		//String d=(String)day.getSelectedItem();
		//String m=(String)month.getSelectedItem();
		//String y=(String)year.getSelectedItem();
		//dob=d+"-"+m+"-"+y;
		for(Student re : list)
		{
			data[r][0]=re.getMobNo();
			data[r][1]=re.getName();
			data[r][2]=re.getPassword();
			data[r][3]=re.getAddress();
			data[r][4]=re.getNoStd();
			data[r][5]=re.getRateStd();
			data[r][6]=re.getNoIsd();
			data[r][7]=re.getRateIsd();
			data[r][8]=re.getNoLocal();
			data[r][9]=re.getRateLocal();
			data[r][10]=re.getNoSms();
			data[r][11]=re.getRateSms();
			data[r][12]=re.getServTax();
			data[r][13]=re.getUserId();
			data[r][14]=re.getTariff();
			if((mobno).equals(data[r][0]))
			{
				//UserDataReadWriteFromFile.writeDatatoFile(list);
				flag=1;
				
				//list1.get(index).setAddress(password);
				//list1.get(index).setPassword(address);
				
				
				//JOptionPane.showMessageDialog(this,"Mobile no.: "+data[r][0]+"\nName: "+data[r][1]+"\nUserId: "+data[r][13]+"\nPassword: "+data[r][2]+"\nAddreess:"+data[r][3]+"\nNo. of Std: "+data[r][4]+"\nrate of Std: "+data[r][5]+"\nNo. of Isd: "+data[r][6]+"\nrate of Isd: "+data[r][7]+"\nNo. of Local: "+data[r][8]+"\nrate of Local: "+data[r][9]+"\nNo. of Sms: "+data[r][10]+"\nrate of Sms: "+data[r][11]+"\nrate of Service tax: "+data[r][12]);
				list.remove(r);
				list.add(r,s);
				UserDataReadWriteFromFile.writeDatatoFile(list);
				JOptionPane.showMessageDialog(this,"Updation Successful..");
				break;
 			}
			r++;
		}
		if(flag==0)
		{
			JOptionPane.showMessageDialog(this,"Searching Unsuccessful..");
		}
		
	}
	}
}
