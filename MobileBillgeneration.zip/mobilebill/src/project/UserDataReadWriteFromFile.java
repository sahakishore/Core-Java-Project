package project;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class UserDataReadWriteFromFile 
{
	public static ArrayList<Student> readDataFromFile()
	{
		ArrayList<Student> list4;
		try
		{ 
		   FileInputStream fin=new FileInputStream("Record.txt");
		   ObjectInputStream oin=new ObjectInputStream(fin);
		   list4=(ArrayList<Student>)oin.readObject();
		   
		   oin.close();
		   fin.close();
		}catch(Exception e)
		 {
			 list4=new ArrayList<Student>();
		 }
		 
		return list4;
	}
	
	public static void writeDatatoFile(ArrayList<Student> wlist)
	{
		try	
		 {
		       FileOutputStream fout=new FileOutputStream("Record.txt");
		       ObjectOutputStream oout=new ObjectOutputStream(fout);
		       oout.writeObject(wlist);
		       
		       oout.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
